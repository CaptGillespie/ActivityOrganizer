﻿using System;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace CBelt.Migrations
{
    public partial class oneMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Logged_In_User",
                columns: table => new
                {
                    UserId = table.Column<int>(nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    FirstName = table.Column<string>(nullable: false),
                    LastName = table.Column<string>(nullable: false),
                    Email = table.Column<string>(nullable: false),
                    Password = table.Column<string>(nullable: false),
                    CreatedAt = table.Column<DateTime>(nullable: false),
                    UpdatedAt = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Logged_In_User", x => x.UserId);
                });

            migrationBuilder.CreateTable(
                name: "happenings",
                columns: table => new
                {
                    HappeningId = table.Column<int>(nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    Title = table.Column<string>(nullable: false),
                    Time = table.Column<TimeSpan>(nullable: false),
                    Date = table.Column<DateTime>(nullable: false),
                    Duration = table.Column<int>(nullable: false),
                    Description = table.Column<string>(nullable: false),
                    CreatedAt = table.Column<DateTime>(nullable: false),
                    UpdatedAt = table.Column<DateTime>(nullable: false),
                    RegisterUserId = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_happenings", x => x.HappeningId);
                    table.ForeignKey(
                        name: "FK_happenings_Logged_In_User_RegisterUserId",
                        column: x => x.RegisterUserId,
                        principalTable: "Logged_In_User",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Attendee",
                columns: table => new
                {
                    AssociationId = table.Column<int>(nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    HappeningId = table.Column<int>(nullable: false),
                    RegisterUserId = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Attendee", x => x.AssociationId);
                    table.ForeignKey(
                        name: "FK_Attendee_happenings_HappeningId",
                        column: x => x.HappeningId,
                        principalTable: "happenings",
                        principalColumn: "HappeningId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Attendee_Logged_In_User_RegisterUserId",
                        column: x => x.RegisterUserId,
                        principalTable: "Logged_In_User",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Attendee_HappeningId",
                table: "Attendee",
                column: "HappeningId");

            migrationBuilder.CreateIndex(
                name: "IX_Attendee_RegisterUserId",
                table: "Attendee",
                column: "RegisterUserId");

            migrationBuilder.CreateIndex(
                name: "IX_happenings_RegisterUserId",
                table: "happenings",
                column: "RegisterUserId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Attendee");

            migrationBuilder.DropTable(
                name: "happenings");

            migrationBuilder.DropTable(
                name: "Logged_In_User");
        }
    }
}
